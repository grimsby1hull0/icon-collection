April, 1998
Welcome to MacTown, U.S.A.!

Introduction:
Welcome to MacTown, Vol. 3! This is the second supplemental set of icons for the MacTown desktop environment. This set includes 40 new icons, including a Steam Locomotive and a couple water-based vehicles, just hints of things to come!

How To make Use of the Icons:
1. You need system 7 or higher.
2. Do a "Get Info" (File menu) on the original MacTown icon file that you want to use.
3. Click on the icon in the window; choose "Copy" (Edit menu).
4. Close the window, then "Get Info" on destination file/disk.
5. Click on the icon, choose "Paste" (Edit menu).
6. Don't forget to e-mail me and let me know what you think!

Register and Contact:
Well, there's really no registration necessary to use this set. But, I would appreciate if you let me know what you think of it! Send a postcard or something, okay? Better yet, send me your own MacTown icons! If I like 'em, I may include them in a future release of MacTown icons sets (credited to you, of course!). Also, if you get on my mailing list, I'll notify you of any updates or Icon sets! Kay? Kay!

Send postcards and letters of adoration to:
Matthew Kelleigh
200 Greenridge Dr. #713
Lake Oswego, OR 97035

Send emails to:
mactown@abalonepress.com

And, as always, Keep checking back at the MacTown Webpage for new releases, updated color schemes, and New Icons and Desktop Patterns!
http://www.abalonepress.com/mactown

Enjoy!


MacTown and all Icons included in this set are created by and �1997 Matthew Kelleigh. 