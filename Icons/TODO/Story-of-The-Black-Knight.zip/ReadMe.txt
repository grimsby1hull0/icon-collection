
Calle's Custom Icons

I like to personalize everything about my work, and I work a lot in front of my computer. 
So I started to collect icons, made by others. But often I didn't find the perfect icon for a particular use. 
Working as an illustrator artist, I just can't settle with the boring original file icons, 
and using only icons made by others also becomes a drag after a while.  
So I started making my own icons instead, and soon I discovered how fun that was. 
Then I continued making them. And my collection grew, and grew, and grew...
My icons are made in a combination of Photoshop and ResEdit. 
Then I get the best of both of these programs.  

____________________________________________________________________

� The Black Knight Icons 

This set of icons originates from a frequent e-mail correspondence with Brian Brasher, another icon artist - more known to most iconists and collectors as Ikthusian.
By sudden inspiration I made up a story, which became a "cliffhanger" through a series of letters. And since both Brian and I are icon artists, it was not so strange that I got the idea to draw icons on the theme of this story.
For the benefit of you who just downloaded these icons, that you may understand a little bit more about what these icons represent, I have also added a textfile with this story for you to read.

____________________________________________________________________

Special thanks for inspiring me to make this set:
Brian B., Dave B. and Frank B.

These Icons

are Freeware � you may use them freely for personal purposes. 
But if you want to use my designs elsewhere, like for a commercial purpose, you have to contact me 
to settle all the legal and financial stuff.
If you like them and use them, please tell me! 
You can either mail me at cjr@telia.com, or call, fax, or send me a letter or a postcard. 
Maybe You have made some good-looking icons for my collection?
Have Fun!


Best wishes from

Carl Johan Rehbinder
Rehbinder MultiArt Productions
Voxnegr�nd 7
S-128 43  BAGARMOSSEN
SWEDEN
Tel/fax: +46-8-649 41 49

E-mail: cjr@telia.com
Homepage: http://www.multiart.nu/cci
