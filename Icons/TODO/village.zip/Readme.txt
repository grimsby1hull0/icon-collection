
I like to personalize everything about my work, and I work a lot in front of my computer. 
So I started to collect icons, made by others. But often I didn't find the perfect icon for a particular use. 
Working as an illustrator artist, I just can�t settle with the boring original file icons, 
and using only icons made by others also becomes a drag after a while.  
So I started making my own icons instead, and soon I discovered how fun that was. 
Then I continued making them. And my collection grew, and grew, and grew...
My icons are made in a combination of Photoshop and ResEdit. 
Then I get the best of both of these programs.  

____________________________________________________________________

� The Village Icons 

Becoming a citizen of IconTown seemed like a good idea, so for that purpose I made a little house.
The first house I made was "Joe's Garage". 
When I got that placed at IconTown I was inspired enough to build some more houses. So I did. 
But I thought that the first garage was a little boxy, so I made another one.
Now I'm probably the largest inhabitant of IconTown, counting the amount of houses there.
To mention just a little bit about the different houses � being Swedish, I just had to make a couple 
of typical Swedish country houses, and because of my interest in history I made the medieval 
knight's pavillions. 
There used to be a couple of Native American Tipis in this set, but I expanded the Native American 
living facility collection so much that I made a separate set of icons with that only.
The one I call "My Pavillion" is a true replica of my own, full-size pavillion. I have constructed 
and sown it all by myself and I can live in it during summer holidays with my whole family.

____________________________________________________________________

These Icons

are Freeware � you may use them freely for personal purposes. 
But if you want to use my designs elsewhere, like for a commercial purpose, you have to contact me 
to settle all the legal and financial stuff.
If you like them and use them, please tell me! 
You can either mail me at cjr@telia.com, or call, fax, or send me a letter or a postcard. 
Maybe You have made some good-looking icons for my collection?
Have Fun!


Best wishes from

Carl Johan Rehbinder
Rehbinder MultiArt Productions
Voxnegr�nd 7
S-128 43  BAGARMOSSEN
SWEDEN
Tel/fax: +46-8-649 41 49

E-mail: cjr@telia.com
Homepage: http://www.multiart.nu/cci


____________________________________________________________________
