Native American Icons
Copyright (c) 2003, e-Mail: "iampaiute at cs.com"

Created by Robert Smith


Feel free to use these icons as you see fit for your own personal use, providing you include
this file. Please do not claim them to be your work, and you charge no money for
them. Please do not change them.

I make them for the advancement and understanding of the Native American Indian culture. 
I am a Northern Paiute
and want to further Native American Indian culture.
The Caddo icons are dedicated to a Caddo by the name of Sonny Del Castillo. 

Enjoy. Thank you.


Robert Smith
Agi-ticutta numu nana
e-Mail: "iampaiute at cs.com"