October, 1997
Welcome to MacTown, U.S.A.!

Introduction:
MacTown is an idea I had at work one day, after having been introduced to the wide wacky world of Macintosh customization and icon design. It occurred to me to create a set of icons that worked with a desktop pattern to make what appeared to be a small town on the Desktop. Taking inspiration from SimCity, Legos, Playmobil, and Model Train sets, I came up with MacTown. There are currently four sets of icons that work together, along with the desktop pattern and a Kaleidoscope Color Scheme, to create the wondrous Majesty that Is MacTown! I hope you enjoy this first release of MacTown icons, and I encourage you to create your own and send them to me! If I like them, I may include them in a future release! Additional Icon sets, the MacTown Streets Desktop Pattern and the Kaleidoscope Color Schemes are available at http://www.abalonepress.com/mactown/ !

How To make Use of the Icons:
1. You need system 7 or higher.
2. Do a "Get Info" (File menu) on the original MacTown icon file that you want to use.
3. Click on the icon in the window; choose "Copy" (Edit menu).
4. Close the window, then "Get Info" on destination file/disk.
5. Click on the icon, choose "Paste" (Edit menu).
6. Don't forget to e-mail me and let me know what you think!

Register and Contact:
Well, there's really no registration necessary to use this set. But, I would appreciate if you let me know what you think of it! Send a postcard or something, okay? Better yet, send me your own MacTown icons! If I like 'em, I may include them in a future release of MacTown icons sets (credited to you, of course!). Also, if you get on my mailing list, I'll notify you of any updates or Icon sets! Kay? Kay!

Send postcards and letters of adoration to:
Matthew Kelleigh
200 Greenridge Dr. #713
Lake Oswego, OR 97035

Send emails to:
matthew@abalonepress.com

Enjoy!

Final Note: 
While I was busily creating this little set, Gedeon Maheux (Iconfactory) noticed a similarity to IconTown (http://www.icontown.de/index.htm). I was not aware of IconTown when I began this project, but it just goes to show you that there's only so many new ideas out there. Anybody interested in MacTown or similar projects should definitely check out IconTown!

MacTown and all Icons included in this set are created by and �1997 Matthew Kelleigh. 
