November, 1997
Welcome to MacTown, U.S.A.!

Introduction:
When I first introduced MacTown to the public a couple months ago, I promised an Icon a Day to expand your MacTown collection! And here I am, making good on that promise with the first release of MacTown Supplemental Icons (also know as MacTown, Vol. 2)! There are a number of icon sets that work together, along with the desktop pattern and a Kaleidoscope Color Scheme, to create the wondrous Majesty that is MacTown! I hope you enjoy Volume Two of the MacTown Icons, and I encourage you to create your own and send them to me! If I like them, I may include them in a future release!

How To make Use of the Icons:
1. You need system 7 or higher.
2. Do a "Get Info" (File menu) on the original MacTown icon file that you want to use.
3. Click on the icon in the window; choose "Copy" (Edit menu).
4. Close the window, then "Get Info" on destination file/disk.
5. Click on the icon, choose "Paste" (Edit menu).
6. Don't forget to e-mail me and let me know what you think!

Register and Contact:
Well, there's really no registration necessary to use this set. But, I would appreciate if you let me know what you think of it! Send a postcard or something, okay? Better yet, send me your own MacTown icons! If I like 'em, I may include them in a future release of MacTown icons sets (credited to you, of course!). Also, if you get on my mailing list, I'll notify you of any updates or Icon sets! Kay? Kay!

Send postcards and letters of adoration to:
Matthew Kelleigh
200 Greenridge Dr. #713
Lake Oswego, OR 97035

Send emails to:
mactown@abalonepress.com

And, as always, Keep checking back at the MacTown Webpage for new releases, updated color schemes, and New Icons and Desktop Patterns!
http://www.abalonepress.com/mactown

Enjoy!


MacTown and all Icons included in this set are created by and �1997 Matthew Kelleigh. 
