
The following text is from the original FAQ Section from IronDevil's Website
http://www.din.or.jp/~irondv/

----------------------------------

Are these sets free?

IronDevil's icons are all freeware.
But these icons may not be used for any commercial purposes.
They are just for personal use.


Is it OK to give the sets to my friends?

No problem.
When giving them, please add the readmes and the mail address.

----------------------------------

IronDevil (irondv@din.or.jp)
http://www.din.or.jp/~irondv/