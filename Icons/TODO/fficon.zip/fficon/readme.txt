�yName�zFirstfood icon
�yVersion�z2.0
�yAuthor�zKAZUTAKA2000
The icon collection of the fast food which is delicious.
Thank you download.
Though reproduction is free, it asks for contact as much as possible by mail.
Insert it without changing all the files which contain a document when you reprint it.
            
�@�@�@�@�@�@
----------------------------------------------------------------------------------------------------------
KAZUTAKA2000
�@IconMuseum�@homepage:
http://members.tripod.co.jp/kazutaka2000/
Mail address:
kazutaka2000@mcn.ne.jp
please�@tell an impression.

----------------------------------------------------------------------------------------------------------
�@Let's meet again.
�@thanks.
