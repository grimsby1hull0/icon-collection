
Contents
The icon set "Bar uekiya 2.0" includes 30 icons for Macintosh.
(20 spirits bottles, and 10 canned beers.)
In addition, you will get a warm welcome from the handsome bartender.


Tools for create icons
Power Macintosh 8500/G3 300
Claris Works 4.0v4

...and many glasses of beer & bourbon whiskey.


Legal Stuff
"Bar Uekiya 2.0" is freeware, but this does not mean you can use it for whatever purposes. 
These icons may NOT be used for any commercial purposes. If you want to put this archive to CD-ROM that comes with commercial books, magazines, etc.. , you are required to contact me and must get permission in advance.

If you want to use these icons for your personal home page, please send me an e-mail and let me know the URL of your page.

________________________________________
Brown (Eiichi Ueki)
e-mail: ei_ueki@qa2.so-net.ne.jp
home page: http://members.tripod.com/~G_Brown/